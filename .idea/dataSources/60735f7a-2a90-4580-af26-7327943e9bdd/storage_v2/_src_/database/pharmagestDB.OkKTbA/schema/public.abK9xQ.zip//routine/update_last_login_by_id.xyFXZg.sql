create procedure update_last_login_by_id(IN user_id integer)
    language plpgsql
as
$$
BEGIN
    UPDATE utilisateur
    SET dernier_login = NOW()
    WHERE utilisateur_id = user_id;
END;
$$;

alter procedure update_last_login_by_id(integer) owner to postgres;

